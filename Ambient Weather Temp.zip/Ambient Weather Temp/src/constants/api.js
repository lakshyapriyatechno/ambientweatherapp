const api = {
  base_url: "https://api.openweathermap.org/data/2.5",
  key: "5968f7e4d38f0827d96375371eaa42eb",
};

export default api;
