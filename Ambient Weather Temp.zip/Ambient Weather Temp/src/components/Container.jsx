const Container = ({ sx, children }) => {
  return (
    <div
      className={`p-3 flex-grow rounded-md drop-shadow-lg ${sx}`}
      style={{ height: "450px", backgroundColor: "#dddbcb" }}
    >
      {children}
    </div>
  );
};

export default Container;
